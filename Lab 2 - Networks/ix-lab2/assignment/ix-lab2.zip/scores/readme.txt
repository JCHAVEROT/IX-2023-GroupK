This folder contains the results for exercise 2.4.1.
